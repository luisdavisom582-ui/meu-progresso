-- Acesso administrativo e contagem aproximada de visitas.
-- Executar no projeto Supabase conectado ao site.
create table if not exists public.site_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('owner', 'admin')),
  created_at timestamptz not null default now()
);
alter table public.site_admins enable row level security;
revoke all on public.site_admins from anon, authenticated;
grant all on public.site_admins to service_role;

-- Só a conta proprietária inicial pode ser promovida a responsável principal.
insert into public.site_admins (user_id, role)
select id, 'owner' from auth.users where id = '__UUID_DA_CONTA_PROPRIETARIA__'
on conflict (user_id) do update set role = 'owner';

-- Numeração fixa das contas administrativas: responsável é sempre nº 1;
-- novos administradores recebem o próximo número disponível na autorização.
alter table public.site_admins add column if not exists badge_number integer;
with unnumbered as (
  select user_id,
    row_number() over (
      order by case when user_id = '__UUID_DA_CONTA_PROPRIETARIA__'::uuid then 0 else 1 end,
        created_at, user_id
    ) + coalesce((select max(badge_number) from public.site_admins), 0) as next_number
  from public.site_admins
  where badge_number is null
)
update public.site_admins admins
set badge_number = unnumbered.next_number
from unnumbered
where admins.user_id = unnumbered.user_id;
create unique index if not exists site_admins_badge_number_key on public.site_admins (badge_number);
alter table public.site_admins alter column badge_number set not null;

create table if not exists public.site_visit_sessions (
  visit_day date not null,
  session_hash text not null,
  created_at timestamptz not null default now(),
  primary key (visit_day, session_hash)
);
alter table public.site_visit_sessions enable row level security;
revoke all on public.site_visit_sessions from anon, authenticated;
grant all on public.site_visit_sessions to service_role;

-- Equipe operacional, separada dos administradores e suas insígnias.
create table if not exists public.site_staff (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('analyst', 'support')),
  added_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);
alter table public.site_staff enable row level security;
revoke all on public.site_staff from anon, authenticated;
grant all on public.site_staff to service_role;
