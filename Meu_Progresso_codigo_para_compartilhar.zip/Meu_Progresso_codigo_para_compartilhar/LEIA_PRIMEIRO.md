# Meu Progresso — pacote para VS Code

## Abrir o projeto

1. Extraia este ZIP para uma pasta.
2. No VS Code, use **Arquivo → Abrir Pasta** e escolha `Meu_Progresso_codigo_para_compartilhar`.
3. Abra `index.html` com a extensão **Live Server** para ver o site.
4. Leia `README.md` e `CONFIGURAR_LOGIN.md` para entender o projeto e os serviços conectados.

Os arquivos principais do site ficam juntos nesta pasta para preservar os caminhos usados pelo HTML e pelo service worker. `supabase/` contém as funções do servidor. Os arquivos `.sql` criam e configuram recursos do banco.

## Configuração importante

- `community-rate-limit.sql` precisa ser executado no SQL Editor antes de publicar a função `community-submit` atualizada. Ela exige e-mail confirmado e limita a três tentativas de relato por dia UTC.
- O diário já limita respostas da IA a dez por conta por dia.
- O UUID da conta proprietária foi substituído por `__UUID_DA_CONTA_PROPRIETARIA__` nos arquivos de configuração administrativa. Para só ler ou apresentar o código, deixe assim. Para configurar uma instância própria, substitua pelo UUID certo nos quatro arquivos marcados antes de aplicar SQL ou publicar funções.
- Segredos como `OPENAI_API_KEY` e `SUPABASE_SERVICE_ROLE_KEY` não devem ser colocados nos arquivos do site; guarde-os nos Secrets do Supabase.
- A configuração pública do `index.html` ainda aponta para o projeto Supabase de desenvolvimento. Não crie contas nem publique relatos de teste nessa instância.
- A pasta contém documentos legais com campos do responsável ainda pendentes; não publique como definitivos sem preenchê-los e revisar as configurações reais.

A folha `editorial.css` define a identidade visual e os ajustes responsivos do layout.
