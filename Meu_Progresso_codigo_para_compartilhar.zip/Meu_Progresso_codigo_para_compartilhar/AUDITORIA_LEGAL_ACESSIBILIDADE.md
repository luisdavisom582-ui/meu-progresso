# Relatório de revisão jurídica, privacidade e acessibilidade

**Projeto:** Meu Progresso  
**Revisão do código local:** 28/10/2026  
**Escopo:** leitura estática de `index.html`, `community.js`, `community-review.js`, `sw.js`, páginas legais, assets locais e configuração presente nos arquivos do projeto. Não houve acesso ao domínio de produção, painéis de provedores, configuração do Supabase/OpenAI, nem teste manual com leitor de tela ou vários dispositivos.

## O que foi preparado

- `termos.html`: termos de uso iniciais, com escopo do serviço, regras básicas de conta e comunidade, conteúdo de usuários, limites da IA e campos para identificação e contato do responsável.
- `cookies.html`: aviso sobre armazenamento local/de sessão, cache offline, estatística opcional e serviços externos observados no código.
- `reembolsos.html`: explica que não há checkout/pagamento implementado no código revisado e trata o direito de arrependimento sem tentar reduzir direitos legais.
- `privacidade.html` e `POLITICA_DE_PRIVACIDADE.md`: descrevem dados, finalidades, compartilhamentos e pontos a confirmar sobre retenção, provedores, exclusão e contato.
- `index.html`: links legais no rodapé e navegação móvel; preferência para estatísticas com aceitar/recusar; consentimento ao criar conta; avisos separados para salvar check-in/diário e para enviar o diário à IA; foco visível, pular para conteúdo, diálogos com suporte a teclado e melhorias de contraste.
- `community.js`: perfil público passa a exigir escolha explícita para exibir o perfil nas publicações; essa exibição fica desligada por padrão; ajustes de teclado/foco no recorte de imagem.
- Exclusão da conta/navegador tenta remover arquivos dos buckets de fotos de relatos e mídia de perfil. A política descreve corretamente como tentativa, não como apagamento garantido de backups do provedor.
- `sw.js`: versão do cache atualizada e páginas legais incluídas no app shell offline.

## Rastreamento e dados

No código local não foram encontrados Google Analytics, Google Tag Manager ou pixels publicitários. Havia uma contagem própria de visitas; agora ela só é enviada depois de aceitar estatísticas. Recusar impede novas contagens, mas não apaga números agregados anteriormente gravados.

O código usa armazenamento do navegador para dados e preferências; Supabase para login/dados/arquivos quando configurado; OpenAI quando a pessoa pede uma resposta de diário ou envia conteúdo comunitário para moderação; jsDelivr para carregar a biblioteca Supabase; e Google Maps quando a pessoa abre uma busca de atendimento. Isso não verifica scripts/injeções configurados fora dos arquivos do repositório.

Os formulários de cadastro pedem e-mail e senha; check-in, diário, envio de relato, imagem e região ampla são opcionais e têm avisos de finalidade. O diário só é enviado à IA mediante ação e autorização separada. Isso reduz coleta desnecessária na interface, mas ainda é preciso verificar todos os campos e tabelas no banco e funções do servidor.

## Acessibilidade

Foram acrescentados texto alternativo às imagens presentes no HTML, rótulos acessíveis a conteúdo gráfico dinâmico, link para pular ao conteúdo, foco de teclado destacado, suporte de foco/teclas nos diálogos e recorte de imagem, rótulos de navegação e redução de movimento. Textos cinza comuns foram escurecidos para melhorar contraste.

A checagem automática simples encontrou: nenhum `id` duplicado nas cinco páginas analisadas, nenhuma imagem HTML sem atributo `alt` e nenhum link/arquivo local quebrado. Os blocos JavaScript inline e os arquivos JavaScript examinados passaram em verificação de sintaxe. Essas checagens não certificam WCAG 2.2 AA; ainda falta percorrer todas as telas com teclado e leitor de tela, avaliar contraste de todos os estados/temas e conferir em celular/zoom.

## Direitos autorais e imagens

Não foram encontrados embeds de imagens de bancos externos no HTML revisado. O `icon.svg` é um recurso local; os arquivos não registram autor ou licença, então a titularidade/origem precisa ser confirmada por quem forneceu o projeto. Fotos de perfil e comunidade são enviadas por usuários: os termos preservam a titularidade deles e descrevem autorização limitada de exibição/moderação. A equipe deve remover conteúdo quando houver reclamação fundamentada e manter procedimento de denúncia. A auditoria do código não comprova direitos de imagens que venham a ser carregadas em produção.

## Dados e decisões que faltam antes de publicar

1. Substituir `[preencher ...]` por nome/razão social do controlador, contato de privacidade e endereço aplicável. Informar CNPJ/CPF e dados de fornecedor quando pertinentes ao modelo real do serviço.
2. Confirmar a região do projeto Supabase, contratos/suboperadores, regras de Storage/RLS, backups, retenção e exclusão. Confirmar também quais funções estão implantadas e quais dados elas registram.
3. Definir e documentar prazos concretos para diário, relatos, denúncias, logs e backups; a expressão “pelo período necessário” precisa de critérios internos reais.
4. Documentar a base legal por finalidade e a avaliação específica para dados que podem revelar saúde/estado emocional. Checkboxes ajudam na transparência, mas não tornam automaticamente todo tratamento conforme à LGPD.
5. Validar o fluxo de atendimento a pedidos LGPD (acesso, correção, portabilidade quando aplicável, informação e eliminação), canal e prazo operacional. O registro de aceite dos termos é metadado enviado pelo cliente e não é prova inviolável; se isso for necessário, registrar aceite no servidor.
6. Verificar configuração de retenção da conta OpenAI e dados enviados pela moderação. `store:false` não significa retenção zero em todos os controles do provedor.
7. Conferir o site publicado e a resposta da função de visitas para garantir que o consentimento opcional também é respeitado no servidor; o código do navegador não controla uma chamada direta à função.
8. Confirmar proveniência/licença do ícone e obter autorização para toda imagem/cópia de terceiros que venha a ser usada.
9. Fazer revisão jurídica final antes de publicação comercial ou abertura ao público. Nenhum arquivo deste projeto pode prometer conformidade legal absoluta.

## Fontes oficiais consultadas

- [Lei Geral de Proteção de Dados — Lei nº 13.709/2018](https://www.presidencia.gov.br/ccivil_03/_ato2015-2018/2018/lei/l13709compilado.htm)
- [ANPD — Direitos dos titulares](https://www.gov.br/anpd/pt-br/assuntos/titular-de-dados-1/direito-dos-titulares)
- [ANPD — Guia Orientativo de Cookies e Proteção de Dados Pessoais (PDF)](https://www.gov.br/anpd/pt-br/centrais-de-conteudo/materiais-educativos-e-publicacoes/processo-guia-orientativo-cookies-e-protecao-de-dados-pessoais.pdf)
- [Código de Defesa do Consumidor](https://www.planalto.gov.br/ccivil_03/leis/l8078compilado.htm) e [Decreto nº 7.962/2013](https://www.planalto.gov.br/ccivil_03/_ato2011-2014/2013/decreto/d7962.htm)
- [W3C — WCAG 2.2](https://www.w3.org/TR/WCAG22/), [contraste mínimo](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html) e [foco visível](https://www.w3.org/WAI/WCAG22/Understanding/focus-visible)
- [OpenAI — controles de dados da API](https://developers.openai.com/api/docs/guides/your-data)
- [Supabase — privacidade](https://supabase.com/privacy) e [residência/transferência de dados](https://supabase.com/legal/privacy-resources/data-residency-and-transfers-faq)

> Este relatório é uma revisão técnica e de transparência do código local, não parecer jurídico nem certificação de conformidade. O projeto precisa dos dados do responsável e da validação das configurações reais antes de publicar os documentos como definitivos.

## Revisão incremental do código — 16/11/2026

Uma lista posterior de observações foi comparada com a versão local atual. Parte dela descrevia uma cópia antiga: o projeto já contém política de privacidade, termos, aviso de cookies, política de pagamentos, exportação e exclusão de dados guardados, foco de teclado, redução de movimento, papéis acessíveis nos diálogos e uma tela de revisão que lista denúncias e permite remover do mural publicações denunciadas. A fila aceita administradores autorizados e analistas; não depende apenas do titular da conta proprietária.

Correções feitas nesta revisão:

- Fotos de relatos agora são abertas no navegador, redimensionadas e regravadas em WebP via canvas antes de serem enviadas. Essa regravação descarta metadados do arquivo, incluindo coordenadas EXIF comuns; elementos visíveis na imagem ainda podem revelar local ou identidade.
- Service worker avançou para `meu-progresso-shell-v8` e passou a buscar primeiro a versão atual da rede, atualizando o cache para uso offline. Isso evita manter indefinidamente um JavaScript antigo enquanto a rede está disponível.
- A função `community-submit` agora exige e-mail confirmado e consulta um limite atômico de três tentativas por usuário e dia UTC antes de acionar a moderação. O novo script `community-rate-limit.sql` deve ser aplicado no Supabase antes de publicar a função atualizada. Tentativas bloqueadas pela moderação também consomem o limite.
- `journal-response` também exige e-mail confirmado. O limite já existente é de dez pedidos por conta/dia, implementado em `setup-supabase.sql`.
- `community-submit` foi explicitada em `supabase/config.toml` com validação JWT obrigatória.
- A política de privacidade agora informa a conversão da imagem antes do envio e seus limites em relação a conteúdo visual identificável.

Pendências que continuam abertas:

- Não há exclusão automática da conta de autenticação Supabase. A função **Apagar meus dados** remove dados associados e arquivos tentados nos buckets, mas mantém o usuário Auth. Não afirmar que ela exclui a conta inteira.
- Limite por conta e confirmação de e-mail dificultam abuso, mas não substituem controle global contra múltiplas contas. CAPTCHA exigiria escolher e configurar um provedor. Teto/alerta de gasto da OpenAI é uma configuração externa que precisa ser feita no painel da conta.
- Não foi adicionada política CSP nem integridade SRI para o CDN. O HTML ainda contém scripts e estilos inline; uma política CSP precisa ser configurada com os cabeçalhos de hospedagem e validada para não bloquear recursos legítimos.
- O mural continua limitado aos 24 relatos mais recentes e ainda não tem paginação.
- Não foi adicionado banner automático de apoio nos relatos “Dia difícil” ou com humor triste. Revisar a política de moderação de autolesão e a apresentação de recursos antes de publicar essa mudança.
- O UUID da conta proprietária permanece parte da configuração de implantação da instância atual. A cópia para compartilhar redige esse UUID; uma nova implantação deve configurar o próprio responsável.

O nome `gpt-6-astra` consta no catálogo oficial e suporta a API Responses. Isso não verifica acesso, créditos ou limites da conta conectada: somente uma chamada autenticada confirma esses itens. Veja [documentação do modelo GPT-6 Astra](https://developers.openai.com/api/docs/models/gpt-6-astra).
