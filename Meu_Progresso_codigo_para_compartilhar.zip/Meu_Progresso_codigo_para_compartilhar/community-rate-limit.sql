-- Execute once in the Supabase SQL Editor to limit community submissions.
-- Each confirmed account may submit up to 3 reports per UTC day.
create schema if not exists private;

create table if not exists private.community_submit_usage (
  user_id uuid not null references auth.users(id) on delete cascade,
  usage_day date not null,
  request_count integer not null default 0 check (request_count >= 0),
  primary key (user_id, usage_day)
);

alter table private.community_submit_usage enable row level security;
revoke all on private.community_submit_usage from public, anon, authenticated;

create or replace function public.consume_community_submit_quota()
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
  caller_id uuid := (select auth.uid());
  used_count integer;
begin
  if caller_id is null then
    return false;
  end if;

  insert into private.community_submit_usage (user_id, usage_day, request_count)
  values (caller_id, (now() at time zone 'utc')::date, 1)
  on conflict (user_id, usage_day) do update
    set request_count = private.community_submit_usage.request_count + 1
    where private.community_submit_usage.request_count < 3
  returning request_count into used_count;

  return used_count is not null;
end;
$$;

revoke all on function public.consume_community_submit_quota() from public, anon;
grant execute on function public.consume_community_submit_quota() to authenticated;
