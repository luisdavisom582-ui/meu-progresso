# Política de Privacidade — Meu Progresso

**Última atualização: 28 de outubro de 2026**

> **Antes de publicar:** o responsável pelo site deve preencher o nome e o e-mail indicados abaixo, confirmar a região e as configurações reais dos provedores e revisar este texto com orientação jurídica adequada. Esta versão foi preparada a partir do código local e não confirma configurações do painel Supabase ou da conta OpenAI.

**Responsável pelo tratamento:** [preencher nome da pessoa ou organização responsável pelo Meu Progresso].  
**Contato para privacidade e exercício de direitos:** [preencher e-mail de contato].

## 1. Sobre esta política

O Meu Progresso permite acompanhar metas e atividades pessoais, escrever sobre o dia a dia, usar recursos opcionais de inteligência artificial, personalizar um perfil e participar de uma comunidade moderada. Esta política explica quais informações podem ser tratadas, para que são usadas e como a pessoa pode exercer seus direitos.

Informações sobre humor, energia e relatos pessoais podem revelar aspectos da saúde emocional. Evite incluir endereço, telefone, documentos ou informações íntimas suas ou de outras pessoas.

## 2. Dados tratados

Conforme os recursos utilizados, o site pode tratar:

- **Conta:** e-mail, identificador único da conta e informações técnicas de autenticação.
- **Progresso:** áreas, metas, atividades registradas, datas, pontos e anotações opcionais.
- **Diário e cuidado:** texto e título do diário, data, resposta de IA quando solicitada, check-ins de humor e energia, pequenas metas e preferências de lembrete.
- **Perfil:** nome de usuário, nome de exibição, biografia, tema, cor, avatar e banner.
- **Comunidade:** texto, tema, humor opcional, cidade/região opcional, imagem, opção de anonimato, reações e denúncias.
- **Dados técnicos:** preferências do site e identificador aleatório de sessão usado para estimar visitas. A contagem representa sessões aproximadas, não pessoas únicas.

O site não solicita sua localização automaticamente. Se você autorizar o navegador, as coordenadas são usadas para montar uma busca no Google Maps. Ao abrir o mapa, o Google recebe os termos dessa busca e aplica as próprias práticas de privacidade.

## 3. Armazenamento

Sem entrar em uma conta, parte do progresso, diário, cuidado e preferências fica no armazenamento local do navegador. Esses dados não são protegidos por uma senha própria do site: alguém com acesso ao dispositivo ou ao perfil do navegador pode vê-los.

Com login, os dados associados à conta podem ser sincronizados e guardados pelos serviços Supabase Auth, Database, Storage e Edge Functions. O responsável deve confirmar a região selecionada para o projeto e os prazos de retenção e backup. Consulte a [Política de Privacidade do Supabase](https://supabase.com/privacy) e as informações sobre [região e transferências de dados](https://supabase.com/legal/privacy-resources/data-residency-and-transfers-faq).

## 4. Comunidade, anonimato e moderação

Enviar um relato é opcional. O texto e, se houver, a imagem são encaminhados à OpenAI para análise automática de conteúdo antes de serem armazenados como pendentes de revisão humana. Se a triagem automática não responder, o envio deve ser interrompido. A análise automática pode falhar e não substitui a revisão humana. Antes de sair do navegador, a foto é convertida para WebP para descartar metadados do arquivo, como localização GPS; detalhes visíveis na imagem ainda podem identificar pessoas ou lugares.

Relatos aprovados podem aparecer no mural. Quando a opção anônima está ativada, o nome não é exibido publicamente, mas a publicação permanece associada internamente à conta para fins de moderação, exclusão e segurança. Quando a pessoa escolhe não publicar anonimamente, o nome de exibição e, conforme suas opções, um link para o perfil público podem aparecer.

O perfil começa privado. Ao torná-lo público, informações escolhidas para a página — que podem incluir nome de usuário, nome de exibição, biografia, foto e banner — ficam visíveis por meio do link público. Denúncias são encaminhadas à equipe autorizada para análise. O suporte de conta não deve acessar o conteúdo das denúncias ou relatos.

## 5. Inteligência artificial e serviços externos

O texto do diário só é enviado à API da OpenAI para gerar uma resposta quando a pessoa solicita essa resposta e marca a autorização apresentada no site. O diário pode ser guardado sem solicitar IA. Textos e imagens de relatos e perfis também podem ser enviados para moderação automática.

O pedido de resposta do diário configura `store: false`. Isso não significa retenção zero em todos os controles do provedor: a OpenAI informa que, por padrão, registros de monitoramento contra abuso podem incluir conteúdo e ser retidos por até 30 dias, sujeito às exceções descritas pelo serviço. A OpenAI informa também que dados enviados à API não são usados para treinar ou melhorar os modelos por padrão, salvo adesão explícita ao compartilhamento. Consulte os [controles de dados da API da OpenAI](https://developers.openai.com/api/docs/guides/your-data).

O Supabase fornece autenticação, banco, arquivos e funções de servidor. O Google Maps é aberto apenas quando a pessoa escolhe um link de busca local. Cada provedor tem suas próprias políticas e pode processar dados em outras localidades, conforme sua configuração e documentação.

## 6. Finalidades

Os dados são usados para fornecer as funções solicitadas, manter e sincronizar a conta, mostrar o progresso, salvar o diário e as preferências, processar respostas de IA pedidas pela pessoa, moderar a comunidade, responder a denúncias, proteger o serviço e cumprir obrigações legais. O responsável deve documentar e confirmar a base legal aplicável a cada finalidade, com atenção especial a informações que possam revelar dados de saúde.

O site não vende dados pessoais. O conteúdo compartilhado publicamente é visível conforme as escolhas de publicação da pessoa. Dados podem ser compartilhados com provedores necessários para operar o site e com autoridades quando a lei exigir.

## 7. Retenção, segurança e exclusão

Dados guardados apenas no navegador permanecem ali até serem removidos pela pessoa ou pelo navegador. Dados da conta ficam pelo período necessário para fornecer o serviço, cumprir obrigações e proteger o sistema. O responsável ainda deve definir prazos específicos de retenção, exclusão de backups e registros de segurança.

O site aplica controles de acesso e regras de segurança nos serviços conectados, mas não pode garantir segurança absoluta. As opções **Baixar meus dados** e **Apagar meus dados** ficam em **Meu dia → Seus dados**. O botão de exclusão tenta remover fotos de relatos e mídia de perfil dos buckets usados pelo site; cópias de segurança e registros dos provedores podem seguir prazos próprios. Também é possível pedir ajuda pelo contato de privacidade indicado no início desta política.

## 8. Direitos da pessoa titular

Nos termos da LGPD, a pessoa pode solicitar confirmação do tratamento e acesso aos dados, correção, informação sobre compartilhamentos, portabilidade nos termos aplicáveis, bloqueio ou eliminação quando cabível e revogação de consentimento. Os pedidos podem ser enviados ao contato de privacidade informado nesta página. A ANPD apresenta informações sobre [direitos das pessoas titulares](https://www.gov.br/anpd/pt-br/assuntos/titular-de-dados-1/direito-dos-titulares).

## 9. Atualizações e contato

Esta política pode ser atualizada quando as funções, integrações ou práticas do site mudarem. A data da versão mais recente será indicada no início. Para dúvidas, solicitações ou exercício de direitos, use: **[preencher e-mail de contato]**.

### Referência legal

Esta política foi estruturada considerando a [Lei Geral de Proteção de Dados Pessoais — Lei nº 13.709/2018](https://www.presidencia.gov.br/ccivil_03/_ato2015-2018/2018/lei/l13709compilado.htm). Ela é um documento inicial de transparência e não substitui a avaliação do responsável sobre o tratamento real nem uma revisão jurídica.
