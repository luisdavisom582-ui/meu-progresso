-- Numeração fixa das contas administrativas: responsável nº 1; próximos acessos seguem a ordem de autorização.
alter table public.site_admins add column if not exists badge_number integer;
with unnumbered as (
  select user_id,
    row_number() over (
      order by case when user_id = '__UUID_DA_CONTA_PROPRIETARIA__'::uuid then 0 else 1 end,
        created_at, user_id
    ) + coalesce((select max(badge_number) from public.site_admins), 0) as next_number
  from public.site_admins
  where badge_number is null
)
update public.site_admins admins
set badge_number = unnumbered.next_number
from unnumbered
where admins.user_id = unnumbered.user_id;
create unique index if not exists site_admins_badge_number_key on public.site_admins (badge_number);
alter table public.site_admins alter column badge_number set not null;