import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
function secretKey() {
  const raw = Deno.env.get("SUPABASE_SECRET_KEYS");
  if (raw) { try { const parsed = JSON.parse(raw); const value = parsed.default ?? Object.values(parsed)[0]; if (typeof value === "string") return value; } catch { /* legacy fallback */ } }
  return Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
}
Deno.serve(async req => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "Método não permitido." }, 405);
  const url = Deno.env.get("SUPABASE_URL") ?? "";
  const secret = secretKey();
  if (!url || !secret) return json({ error: "Páginas de perfil não estão disponíveis agora." }, 503);
  let input: Record<string, unknown>;
  try { input = await req.json(); } catch { return json({ error: "Dados inválidos." }, 400); }
  const username = typeof input.username === "string" ? input.username.trim().toLowerCase() : "";
  if (!/^[a-z0-9_]{3,20}$/.test(username)) return json({ error: "Nome de usuário inválido." }, 400);
  const admin = createClient(url, secret, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: profile, error } = await admin.from("community_profiles")
    .select("user_id,username,display_name,bio,theme,accent_color,avatar_path,banner_path,is_public")
    .eq("username", username).eq("is_public", true).maybeSingle();
  if (error) { console.error("public profile lookup", error); return json({ error: "Não consegui abrir este perfil agora." }, 500); }
  if (!profile) return json({ error: "Este perfil não existe ou está privado." }, 404);
  const { data: adminRows, error: adminError } = await admin.from("site_admins").select("user_id,badge_number");
  let adminBadge: { number: number; label: string } | null = null;
  if (!adminError && adminRows) {
    const badgeNumber = Number(adminRows.find(row => row.user_id === profile.user_id)?.badge_number ?? 0);
    if (badgeNumber >= 1 && badgeNumber <= 3) adminBadge = { number: badgeNumber, label: `Conta ADM ${badgeNumber}` };
  }
  const [avatar, banner] = await Promise.all([
    profile.avatar_path ? admin.storage.from("community-profile-media").createSignedUrl(profile.avatar_path, 600) : Promise.resolve({ data: null, error: null }),
    profile.banner_path ? admin.storage.from("community-profile-media").createSignedUrl(profile.banner_path, 600) : Promise.resolve({ data: null, error: null }),
  ]);
  return json({ ok: true, profile: {
    username: profile.username, display_name: profile.display_name, bio: profile.bio,
    theme: profile.theme, accent_color: profile.accent_color,
    avatar_url: avatar.data?.signedUrl ?? null, banner_url: banner.data?.signedUrl ?? null,
    admin_badge: adminBadge,
  } });
});
