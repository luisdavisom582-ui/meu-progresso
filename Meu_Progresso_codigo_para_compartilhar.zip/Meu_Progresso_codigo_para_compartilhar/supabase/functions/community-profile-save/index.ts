import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
function envKey(name: string, legacyName: string) {
  const raw = Deno.env.get(name);
  if (raw) { try { const parsed = JSON.parse(raw); const value = parsed.default ?? Object.values(parsed)[0]; if (typeof value === "string") return value; } catch { /* legacy fallback */ } }
  return Deno.env.get(legacyName) ?? "";
}
function toBase64(bytes: Uint8Array) {
  let binary = "";
  const chunkSize = 0x8000;
  for (let offset = 0; offset < bytes.length; offset += chunkSize) binary += String.fromCharCode(...bytes.subarray(offset, offset + chunkSize));
  return btoa(binary);
}

Deno.serve(async req => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "Método não permitido." }, 405);
  const url = Deno.env.get("SUPABASE_URL") ?? "";
  const publishable = envKey("SUPABASE_PUBLISHABLE_KEYS", "SUPABASE_ANON_KEY");
  const secret = envKey("SUPABASE_SECRET_KEYS", "SUPABASE_SERVICE_ROLE_KEY");
  const openAiKey = Deno.env.get("OPENAI_API_KEY") ?? "";
  if (!url || !publishable || !secret) return json({ error: "Salvamento do perfil não está configurado." }, 503);
  const authorization = req.headers.get("Authorization") ?? "";
  if (!authorization.startsWith("Bearer ")) return json({ error: "Entre na sua conta para salvar o perfil." }, 401);
  const identity = await fetch(`${url}/auth/v1/user`, { headers: { apikey: publishable, Authorization: authorization } });
  if (!identity.ok) return json({ error: "Sua sessão expirou. Entre novamente." }, 401);
  const user = await identity.json();
  if (!user?.id) return json({ error: "Não consegui confirmar sua conta." }, 401);
  let input: Record<string, unknown>;
  try { input = await req.json(); } catch { return json({ error: "Dados inválidos." }, 400); }

  const username = typeof input.username === "string" && input.username ? input.username : null;
  const displayName = typeof input.display_name === "string" ? input.display_name.trim() : "";
  const bio = typeof input.bio === "string" ? input.bio.trim() : "";
  const theme = typeof input.theme === "string" ? input.theme : "";
  const accent = typeof input.accent_color === "string" ? input.accent_color : "";
  const isPublic = input.is_public === true;
  const showInPosts = input.show_in_posts === true;
  const emoji = typeof input.avatar_emoji === "string" ? input.avatar_emoji : "🌿";
  const avatarPath = typeof input.avatar_path === "string" ? input.avatar_path : null;
  const bannerPath = typeof input.banner_path === "string" ? input.banner_path : null;
  const pathIsOwned = (path: string | null) => path === null || new RegExp(`^${user.id}/[0-9a-f-]{36}\\.webp$`, "i").test(path);
  if ((username && !/^[a-z0-9_]{3,20}$/.test(username)) || displayName.length < 2 || displayName.length > 32 || bio.length > 240 ||
      !["sage", "ocean", "sunset", "lavender"].includes(theme) || !/^#[0-9A-Fa-f]{6}$/.test(accent) ||
      !["🌿", "🌱", "🌻", "☀️", "🌙", "🪷", "⭐", "💛"].includes(emoji) || typeof input.is_public !== "boolean" ||
      typeof input.show_in_posts !== "boolean" || (isPublic && !username) || !pathIsOwned(avatarPath) || !pathIsOwned(bannerPath)) {
    return json({ error: "Confira o nome de usuário e os dados do perfil." }, 400);
  }

  const admin = createClient(url, secret, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: previous, error: readError } = await admin.from("community_profiles")
    .select("username,bio,theme,accent_color,avatar_path,banner_path,is_public,show_in_posts,display_name,avatar_emoji")
    .eq("user_id", user.id).maybeSingle();
  if (readError) { console.error("profile before save", readError); return json({ error: "Não consegui carregar seu perfil para salvar." }, 500); }

  const imagesToReview = isPublic ? [
    avatarPath && (avatarPath !== previous?.avatar_path || !previous?.is_public) ? avatarPath : null,
    bannerPath && (bannerPath !== previous?.banner_path || !previous?.is_public) ? bannerPath : null,
  ].filter((path): path is string => !!path) : [];
  if (isPublic && !openAiKey) return json({ error: "A checagem automática está indisponível. O perfil continua privado até ela voltar." }, 503);
  if (isPublic) {
    let response: Response;
    try {
      response = await fetch("https://api.openai.com/v1/moderations", {
        method: "POST", headers: { Authorization: `Bearer ${openAiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({ model: "omni-moderation-latest", input: `${username}\n${displayName}\n${bio}` }),
      });
    } catch (error) { console.error("profile text moderation request", error); return json({ error: "A checagem automática do texto não respondeu; o perfil não foi publicado." }, 503); }
    if (!response.ok) { console.error("profile text moderation response", response.status); return json({ error: "A checagem automática do texto não concluiu; o perfil não foi publicado." }, 503); }
    const textCategories = (await response.json())?.results?.[0]?.categories;
    if (!textCategories || typeof textCategories !== "object") return json({ error: "Não consegui concluir a checagem automática do texto; o perfil não foi publicado." }, 503);
    const blockedText = ["harassment", "harassment/threatening", "hate", "hate/threatening", "sexual", "sexual/minors", "violence", "violence/graphic", "self-harm", "self-harm/intent", "self-harm/instructions"];
    if (blockedText.some(category => textCategories[category] === true)) return json({ error: "Revise o nome e a descrição para manter um espaço acolhedor." }, 200);
  }
  for (const imagePath of imagesToReview) {
    const { data: file, error: downloadError } = await admin.storage.from("community-profile-media").download(imagePath);
    if (downloadError || !file) { console.error("profile image download", downloadError); return json({ error: "Não consegui validar uma imagem do perfil. Tente enviar novamente." }, 400); }
    if (file.size > 4 * 1024 * 1024) return json({ error: "A imagem do perfil passou do limite de 4 MB." }, 400);
    const bytes = new Uint8Array(await file.arrayBuffer());
    let response: Response;
    try {
      response = await fetch("https://api.openai.com/v1/moderations", {
        method: "POST", headers: { Authorization: `Bearer ${openAiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({ model: "omni-moderation-latest", input: [{ type: "image_url", image_url: { url: `data:image/webp;base64,${toBase64(bytes)}` } }] }),
      });
    } catch (error) { console.error("profile moderation request", error); return json({ error: "A checagem automática não respondeu; o perfil continua privado." }, 503); }
    if (!response.ok) { console.error("profile moderation response", response.status); return json({ error: "A checagem automática não concluiu; o perfil continua privado." }, 503); }
    const categories = (await response.json())?.results?.[0]?.categories;
    if (!categories || typeof categories !== "object") return json({ error: "Não consegui concluir a checagem automática; o perfil continua privado." }, 503);
    const blocked = ["sexual", "sexual/minors", "violence", "violence/graphic", "self-harm", "self-harm/intent", "self-harm/instructions"];
    if (blocked.some(category => categories[category] === true)) return json({ error: "Esta imagem não pode ser usada no perfil. Escolha outra foto ou banner." }, 200);
  }

  if (!isPublic || !showInPosts) {
    const { error: unlinkError } = await admin.from("community_posts").update({ profile_username: null })
      .eq("user_id", user.id).eq("is_anonymous", false).not("profile_username", "is", null);
    if (unlinkError) { console.error("unlink profile from posts", unlinkError); return json({ error: "Não consegui atualizar os links dos seus relatos." }, 500); }
  }

  const { error: saveError } = await admin.from("community_profiles").upsert({
    user_id: user.id, username, display_name: displayName, bio, theme, accent_color: accent,
    avatar_emoji: emoji, avatar_path: avatarPath, banner_path: bannerPath, is_public: isPublic, show_in_posts: showInPosts,
    updated_at: new Date().toISOString(),
  });
  if (saveError) {
    console.error("profile save", saveError);
    return saveError.code === "23505" ? json({ error: "Esse nome de usuário já está em uso. Escolha outro." }, 409) : json({ error: "Não consegui salvar seu perfil." }, 500);
  }
  if (isPublic && showInPosts) {
    const { error: linkError } = await admin.from("community_posts").update({ profile_username: username })
      .eq("user_id", user.id).eq("is_anonymous", false);
    if (linkError) console.error("link public profile to existing non-anonymous posts", linkError);
  }
  return json({ ok: true });
});
