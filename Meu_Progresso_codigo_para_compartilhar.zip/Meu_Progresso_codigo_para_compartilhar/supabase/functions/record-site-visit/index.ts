import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
function key(envName: string, legacyName: string) {
  const raw = Deno.env.get(envName);
  if (raw) { try { const parsed = JSON.parse(raw); const value = parsed.default ?? Object.values(parsed)[0]; if (typeof value === "string") return value; } catch { /* legacy fallback */ } }
  return Deno.env.get(legacyName) ?? "";
}
Deno.serve(async req => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "Método não permitido." }, 405);
  const url = Deno.env.get("SUPABASE_URL") ?? "";
  const secret = key("SUPABASE_SECRET_KEYS", "SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !secret) return json({ error: "Contagem de visitas não configurada." }, 503);
  let input: Record<string, unknown>;
  try { input = await req.json(); } catch { return json({ error: "Dados inválidos." }, 400); }
  if (typeof input.visit_id !== "string" || !/^[0-9a-f-]{36}$/i.test(input.visit_id)) return json({ error: "Visita inválida." }, 400);
  const visitDay = new Date().toISOString().slice(0, 10);
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(`${visitDay}:${input.visit_id}`));
  const sessionHash = [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, "0")).join("");
  const admin = createClient(url, secret, { auth: { persistSession: false, autoRefreshToken: false } });
  const { error } = await admin.from("site_visit_sessions").upsert({ visit_day: visitDay, session_hash: sessionHash }, { onConflict: "visit_day,session_hash", ignoreDuplicates: true });
  if (error) { console.error("record site visit", error); return json({ error: "Não consegui registrar o acesso." }, 500); }
  return json({ ok: true });
});
