import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const OWNER_ID = "__UUID_DA_CONTA_PROPRIETARIA__";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
function key(envName: string, legacyName: string) {
  const raw = Deno.env.get(envName);
  if (raw) { try { const parsed = JSON.parse(raw); const value = parsed.default ?? Object.values(parsed)[0]; if (typeof value === "string") return value; } catch { /* legacy fallback */ } }
  return Deno.env.get(legacyName) ?? "";
}
async function allUsers(admin: ReturnType<typeof createClient>) {
  const users = [];
  for (let page = 1; page <= 1000; page++) {
    const { data, error } = await admin.auth.admin.listUsers({ page, perPage: 1000 });
    if (error) throw error;
    users.push(...data.users);
    if (data.users.length < 1000) break;
  }
  return users;
}
async function rankedAdmins(admin: ReturnType<typeof createClient>) {
  const { data, error } = await admin.from("site_admins").select("user_id,role,badge_number").order("badge_number", { ascending: true });
  if (error) throw error;
  return data ?? [];
}

Deno.serve(async req => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "Método não permitido." }, 405);
  const authorization = req.headers.get("Authorization") ?? "";
  if (!authorization.startsWith("Bearer ")) return json({ error: "Entre na sua conta." }, 401);
  const url = Deno.env.get("SUPABASE_URL") ?? "";
  const publishable = key("SUPABASE_PUBLISHABLE_KEYS", "SUPABASE_ANON_KEY");
  const secret = key("SUPABASE_SECRET_KEYS", "SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !publishable || !secret) return json({ error: "Painel administrativo não configurado." }, 503);
  const identity = await fetch(`${url}/auth/v1/user`, { headers: { apikey: publishable, Authorization: authorization } });
  if (!identity.ok) return json({ error: "Sua sessão expirou. Entre novamente." }, 401);
  const user = await identity.json();
  const admin = createClient(url, secret, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: adminMembership, error: adminMembershipError } = await admin.from("site_admins").select("role").eq("user_id", user.id).maybeSingle();
  const { data: staffMembership, error: staffMembershipError } = await admin.from("site_staff").select("role").eq("user_id", user.id).maybeSingle();
  if (adminMembershipError || staffMembershipError) return json({ error: "Não consegui verificar sua função." }, 500);
  const role = adminMembership?.role === "owner" && user.id === OWNER_ID ? "owner" : adminMembership?.role === "admin" ? "admin" : staffMembership?.role;
  if (!role || !["owner", "admin", "analyst", "support"].includes(role)) return json({ error: "Acesso não autorizado." }, 403);
  let input: Record<string, unknown>;
  try { input = await req.json(); } catch { return json({ error: "Dados inválidos." }, 400); }

  if (input.action === "access") return json({ ok: true, role });
  const ownerOnly = ["list_admins", "add_admin", "remove_admin", "list_staff", "add_staff", "remove_staff"];
  if (ownerOnly.includes(String(input.action)) && (user.id !== OWNER_ID || role !== "owner")) return json({ error: "Somente a conta responsável pode gerenciar a equipe." }, 403);
  if (["stats"].includes(String(input.action)) && !["owner", "admin", "analyst"].includes(role)) return json({ error: "Essa área é reservada a administradores e analistas." }, 403);
  if (input.action === "badge" && !["owner", "admin"].includes(role)) return json({ error: "Identificação disponível somente para administradores." }, 403);

  if (input.action === "badge") {
    try {
      const ranked = await rankedAdmins(admin);
      const number = Number(ranked.find(row => row.user_id === user.id)?.badge_number ?? 0);
      const adminBadge = number ? number <= 3 ? { number, label: `Conta ADM ${number}` } : { number: null, label: "Conta ADM" } : null;
      return json({ ok: true, adminBadge });
    } catch (error) { console.error("admin badge lookup", error); return json({ error: "Não consegui carregar a identificação administrativa." }, 500); }
  }

  if (input.action === "stats") {
    try {
      const [users, visitsResult, ranked] = await Promise.all([
        allUsers(admin),
        admin.from("site_visit_sessions").select("session_hash", { count: "exact", head: true }),
        rankedAdmins(admin),
      ]);
      if (visitsResult.error) throw visitsResult.error;
      const ownRank = Number(ranked.find(row => row.user_id === user.id)?.badge_number ?? 0);
      const adminBadge = ownRank ? ownRank <= 3 ? { number: ownRank, label: `Conta ADM ${ownRank}` } : { number: null, label: "Conta ADM" } : null;
      return json({ ok: true, role, registrations: users.length, visits: visitsResult.count ?? 0, accountCode: `MP-${String(user.id).replaceAll("-", "").toUpperCase()}`, adminBadge: ["owner", "admin"].includes(role) ? adminBadge : null });
    } catch (error) { console.error("admin dashboard stats", error); return json({ error: "Não consegui carregar os indicadores." }, 500); }
  }

  if (input.action === "list_admins") {
    let rows;
    try { rows = await rankedAdmins(admin); }
    catch { return json({ error: "Não consegui carregar a lista de administradores." }, 500); }
    const users = await allUsers(admin);
    const byId = new Map(users.map(item => [item.id, item.email ?? "E-mail não disponível"]));
    return json({ ok: true, admins: rows.map(row => ({ ...row, email: byId.get(row.user_id) ?? "Conta não encontrada" })) });
  }

  if (input.action === "add_admin") {
    if (typeof input.email !== "string" || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.email.trim())) return json({ error: "Digite um e-mail válido." }, 400);
    const targetEmail = input.email.trim().toLowerCase();
    try {
      const users = await allUsers(admin);
      const target = users.find(item => item.email?.toLowerCase() === targetEmail);
      if (!target) return json({ error: "Essa pessoa precisa criar e confirmar a conta no site antes de ser autorizada." }, 404);
      if (target.id === OWNER_ID) return json({ error: "A conta responsável já tem acesso total." }, 409);
      const { data: existing, error: existingError } = await admin.from("site_admins").select("user_id").eq("user_id", target.id).maybeSingle();
      if (existingError) throw existingError;
      if (existing) return json({ ok: true });
      const { error: staffDeleteError } = await admin.from("site_staff").delete().eq("user_id", target.id);
      if (staffDeleteError) throw staffDeleteError;
      const { data: last, error: numberError } = await admin.from("site_admins").select("badge_number").order("badge_number", { ascending: false }).limit(1).maybeSingle();
      if (numberError) throw numberError;
      const nextBadgeNumber = Number(last?.badge_number ?? 0) + 1;
      const { error } = await admin.from("site_admins").insert({ user_id: target.id, role: "admin", badge_number: nextBadgeNumber });
      if (error) throw error;
      return json({ ok: true });
    } catch (error) { console.error("admin add", error); return json({ error: "Não consegui autorizar essa conta." }, 500); }
  }

  if (input.action === "remove_admin") {
    if (typeof input.user_id !== "string" || !/^[0-9a-f-]{36}$/i.test(input.user_id) || input.user_id === OWNER_ID) return json({ error: "Administrador inválido." }, 400);
    const { error } = await admin.from("site_admins").delete().eq("user_id", input.user_id).eq("role", "admin");
    if (error) return json({ error: "Não consegui remover esse administrador." }, 500);
    return json({ ok: true });
  }
  if (input.action === "list_staff") {
    try {
      const { data, error } = await admin.from("site_staff").select("user_id,role,created_at").order("created_at", { ascending: true });
      if (error) throw error;
      const users = await allUsers(admin);
      const byId = new Map(users.map(item => [item.id, item.email ?? "E-mail não disponível"]));
      return json({ ok: true, staff: (data ?? []).map(row => ({ ...row, email: byId.get(row.user_id) ?? "Conta não encontrada" })) });
    } catch (error) { console.error("staff list", error); return json({ error: "Não consegui carregar a equipe." }, 500); }
  }
  if (input.action === "add_staff") {
    if (typeof input.email !== "string" || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.email.trim()) || !["analyst", "support"].includes(String(input.role))) return json({ error: "Informe um e-mail válido e uma função da equipe." }, 400);
    try {
      const users = await allUsers(admin);
      const target = users.find(item => item.email?.toLowerCase() === input.email!.toString().trim().toLowerCase());
      if (!target) return json({ error: "Essa pessoa precisa criar e confirmar a conta no site antes de ser adicionada." }, 404);
      if (target.id === OWNER_ID) return json({ error: "A conta responsável já tem acesso total." }, 409);
      const { data: isAdmin, error: isAdminError } = await admin.from("site_admins").select("user_id").eq("user_id", target.id).maybeSingle();
      if (isAdminError) throw isAdminError;
      if (isAdmin) return json({ error: "Essa conta já é administradora." }, 409);
      const { error } = await admin.from("site_staff").upsert({ user_id: target.id, role: input.role, added_by: user.id }, { onConflict: "user_id" });
      if (error) throw error;
      return json({ ok: true });
    } catch (error) { console.error("staff add", error); return json({ error: "Não consegui adicionar essa conta à equipe." }, 500); }
  }
  if (input.action === "remove_staff") {
    if (typeof input.user_id !== "string" || !/^[0-9a-f-]{36}$/i.test(input.user_id)) return json({ error: "Conta inválida." }, 400);
    const { error } = await admin.from("site_staff").delete().eq("user_id", input.user_id);
    if (error) return json({ error: "Não consegui retirar essa conta da equipe." }, 500);
    return json({ ok: true });
  }
  return json({ error: "Ação inválida." }, 400);
});
