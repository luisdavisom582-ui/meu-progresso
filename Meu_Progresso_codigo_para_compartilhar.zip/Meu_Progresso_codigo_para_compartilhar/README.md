# Guia do projeto — Meu Progresso

Este site ajuda uma pessoa a acompanhar pequenas metas, registrar atividades e refletir sobre o próprio dia. Também tem uma área de comunidade com relatos revisados antes da publicação e informações para buscar apoio em saúde mental.

## Como abrir

1. Abra a pasta `outputs` no Visual Studio Code.
2. Abra o arquivo `index.html` com a extensão **Live Server** (clique com o botão direito e escolha **Open with Live Server**).
3. O site abrirá no navegador, normalmente em `http://127.0.0.1:5500`.

Mantenha todos os arquivos da pasta juntos. O `index.html` usa os outros arquivos de JavaScript, o ícone e o service worker.

## Arquivos principais

- `index.html` e `editorial.css` — estrutura, conteúdo e identidade visual das páginas, com layout responsivo.
- `community.js` — formulário de relatos, prévia e cancelamento de foto, mural, reações, recorte de avatar/banner e perfil personalizado.
- `community-profile-setup.sql` — perfil público opcional, nome de usuário único e políticas do bucket privado para fotos e banners.
- `supabase/functions/community-profile-save/index.ts` — valida e salva o perfil; imagens passam pela checagem automática antes de tornar a página pública.
- `supabase/functions/community-public-profile/index.ts` — exibe somente perfis públicos e fornece links temporários para fotos e banners.
- `community-review.js` — central da equipe separada da Comunidade, revisão por administradores/analistas, orientações ao Suporte e gestão de funções pela conta responsável.
- `supabase/functions/community-submit/index.ts` — valida o relato, envia texto e foto para a verificação automática e guarda os aprovados pela triagem como pendentes.
- `supabase/functions/community-review/index.ts` — entrega a fila de relatos a administradores e analistas, e salva a decisão humana. Suporte não acessa relatos. As fotos são mostradas por links temporários.
- `supabase/functions/admin-dashboard/index.ts` — verifica os papéis no servidor, mostra totais e permite somente à conta responsável gerenciar administradores, analistas e suporte.
- `supabase/functions/record-site-visit/index.ts` — conta sessões diárias aproximadas sem guardar o identificador original do navegador.
- `admin-setup.sql` — cria as tabelas protegidas de administradores, equipe e visitas e promove a conta responsável inicial.
- `staff-setup.sql` — cria separadamente os papéis protegidos de analista e suporte.
- `admin-badge-setup.sql` — atribui um número permanente a cada conta administrativa autorizada.
- `supabase/functions/journal-response/index.ts` — função publicada de respostas de IA para o diário; só recebe texto quando a pessoa pede e autoriza o envio.
- `supabase/functions/send-due-push/index.ts` — envio de lembretes push, quando o servidor push estiver configurado.
- `community-setup.sql`, `community-enhancements.sql` e `setup-supabase.sql` — instruções que criam tabelas, regras de acesso e recursos do banco.
- `community-rate-limit.sql` — limita a três envios de relatos por conta confirmada por dia (UTC); execute no SQL Editor do Supabase antes de publicar a função atualizada `community-submit`.
- `supabase/config.toml` — configurações das funções do Supabase.
- `sw.js`, `manifest.webmanifest` e `icon.svg` — suporte de instalação e notificações do site.
- `CONFIGURAR_LOGIN.md` — guia detalhado de configuração do Supabase e recursos conectados.
- `privacidade.html` e `POLITICA_DE_PRIVACIDADE.md` — política de privacidade. `termos.html`, `cookies.html` e `reembolsos.html` — páginas legais e aviso de armazenamento do navegador. Preencha os dados do responsável e revise configurações antes de publicar.

## Como explicar a revisão dos relatos

1. A pessoa envia um relato e, se quiser, uma foto. A foto é convertida no navegador para WebP antes de ser transmitida, descartando metadados de localização do arquivo.
2. Contas com e-mail confirmado têm até três tentativas de envio por dia, configuradas no SQL `community-rate-limit.sql`.
3. O servidor pede uma triagem automática à OpenAI. Se a análise não puder ser concluída, o envio é interrompido.
4. Se passar pela triagem, o relato fica **pendente**. A IA não o publica sozinha.
5. Uma conta autorizada abre **Comunidade → Revisão da comunidade**, lê o texto, confere a foto e escolhe **Aprovar e publicar** ou **Remover relato**.

## Administradores e IDs das contas

- A conta proprietária inicial é definida no servidor pelo ID cadastrado em `admin-setup.sql`. Só ela pode conceder ou retirar acesso de administrador.
- Para autorizar alguém, a pessoa primeiro precisa criar e confirmar a própria conta. Depois, a proprietária informa o e-mail dela no painel administrativo da área Comunidade.
- Cada conta vê seu ID único em **Saúde mental → Seus dados**. O ID vem do identificador Supabase e serve apenas para identificar a conta; não é senha e não concede acesso.
- O painel mostra o total de contas e sessões diárias aproximadas. Sessões não são pessoas únicas, e o número pode incluir várias visitas da mesma pessoa. As três primeiras contas administrativas autorizadas recebem as insígnias: responsável nº 1 em dourado, admin nº 2 em bronze e admin nº 3 em prata. Os números ficam associados às contas restantes mesmo que outro acesso seja removido.
- Na aba **Meu perfil**, cada pessoa pode escolher nome de usuário, descrição, tema, cor principal e recortar a foto e o banner antes de salvar. O perfil começa privado; para compartilhar, escolha um nome de usuário, torne-o público e copie o link.
- Fotos e banners ficam num bucket privado e só recebem links temporários depois que o perfil é publicado. A checagem automática bloqueia categorias sexuais, violentas e de automutilação; se a checagem falhar, a página não é publicada.
- Ao publicar um relato sem anonimato, a pessoa pode permitir um link ao perfil público. Relatos enviados anonimamente não exibem nem vinculam o perfil.

## Configurar o perfil no Supabase

1. Confira que `admin-setup.sql` já foi executado e, depois, execute `admin-badge-setup.sql` para atribuir os números administrativos.
2. Execute `community-profile-setup.sql` depois de `community-setup.sql`.
3. Publique as funções `community-profile-save` (com JWT obrigatório) e `community-public-profile` (com validação própria de perfil público).
4. Confirme que `OPENAI_API_KEY` continua configurada nas Edge Function Secrets; imagens não são publicadas se a análise automática estiver indisponível.

A triagem automática pode errar. A revisão humana continua necessária, e o mural não substitui atendimento profissional ou de emergência.

## Tecnologias usadas

- HTML, CSS e JavaScript no site.
- Supabase Auth para contas; banco Postgres para registros; Storage para fotos; Edge Functions para operações protegidas.
- API de moderação da OpenAI chamada apenas pelo servidor.

## Antes de compartilhar

- Para mostrar o projeto, envie a pasta `outputs` inteira; não envie apenas `index.html`.
- O site está conectado ao projeto Supabase usado no desenvolvimento. Uma pessoa que abrir a página poderá ver conteúdo público do mural. Não peça para ela enviar relatos de teste ou usar sua conta.
- A URL do Supabase e a chave **Publishable** no `index.html` são destinadas ao navegador. Mesmo assim, não compartilhe senhas, chaves secretas do Supabase, `OPENAI_API_KEY` nem arquivos com dados pessoais.
- A função de revisão está configurada para a conta de moderação do projeto atual. Em uma cópia do projeto, o responsável precisará configurar a própria conta autorizada no servidor antes de usar a revisão.
- Se for publicar o site para outras pessoas, revise primeiro as políticas de privacidade, segurança, moderação e suporte. O mural trata de relatos pessoais.

## Como apresentar o código

Uma forma simples de explicar é: “O HTML organiza as páginas; o CSS define o visual; o JavaScript faz os botões e formulários funcionarem; e o Supabase guarda as contas e os dados. As funções do servidor protegem as chaves e fazem a triagem dos relatos.”

O `index.html` ainda reúne bastante código em um único arquivo. Por isso pode parecer longo; aos poucos, partes maiores podem ser separadas em arquivos próprios.
