# Relatório de revisão — Meu Progresso

**Atualizado:** 19/10/2026  
**Escopo:** análise dos arquivos do site, sincronização e privacidade Supabase, mural, revisão, moderação, resposta de IA e cache offline. Também apliquei as correções no projeto Supabase conectado.  
**Limite:** não executei uma bateria de testes nem simulei todos os fluxos de usuário. As Edge Functions foram aceitas e publicadas pelo Supabase; isso não substitui a conferência manual no navegador.

## Correções feitas

- **Sincronização sem apagar cópias locais:** registros e anotações do diário agora são mesclados por ID; alterações locais pendentes tentam sincronizar e permanecem no navegador caso a nuvem falhe.
- **Exclusão de registros:** a interface espera a exclusão na nuvem antes de remover o item local e mostra erro se a nuvem não confirmar.
- **Exclusão do diário:** a anotação continua visível se a remoção na nuvem falhar.
- **Apagar meus dados:** a interface verifica erros em todas as tabelas e fotos; apaga as fotos em lotes sem pular arquivos e só limpa o navegador após concluir a etapa na conta. Sem login, informa que apagou apenas o navegador.
- **Revisão humana:** a fila agora apresenta relatos pendentes e denúncias; o moderador consegue abrir texto/foto, retirar um relato do mural e marcar uma denúncia como revisada. A decisão fica registrada com data e conta revisora em vez de apagar o histórico.
- **Moderação automática:** a lista de categorias bloqueadas agora cobre texto sexual, violento e de automutilação, além das categorias já bloqueadas. A publicação só segue depois de a análise automática responder; a aprovação humana continua necessária.
- **Resumo por período:** os números de registros, dias ativos e pontos mudam entre semana, mês e todo o período.
- **Exportação:** inclui progresso, diário, cuidados, perfil, publicações próprias e denúncias próprias quando o Supabase permite a consulta. O JSON informa se publicações/denúncias entraram. Fotos não são incorporadas ao arquivo.
- **Resposta de IA:** erros de saldo esgotado e limite diário aparecem com mensagens próprias. Foi configurado limite de 10 respostas por conta por dia no Supabase, sem depender do navegador.
- **Atualização offline:** a versão do cache passou de `v1` para `v2` para que o navegador descarte recursos antigos.

## Mudanças aplicadas no Supabase

Foram aplicadas migrações para o contador privado de uso da IA, acesso do titular às próprias denúncias/exportação, registro da revisão humana e índices para consultas por conta. As funções publicadas estão ativas:

- `community-submit` — versão 9
- `community-review` — versão 3
- `journal-response` — versão 4

A checagem de advisors não encontrou alertas de política RLS após as mudanças. Ela apontou que a **proteção contra senhas comprometidas está desativada** no Auth. É uma configuração que ainda precisa ser ligada no painel do Supabase em **Authentication → Password Security**.

## Pendências e limites conhecidos

- A resposta de IA continuará sem responder enquanto a API OpenAI estiver sem créditos. A última falha conhecida foi `credit_balance_exhausted`; não fiz chamadas novas para não gerar gasto.
- O arquivo exportado não inclui os arquivos de imagem em si; inclui os caminhos das fotos associadas às publicações.
- Não percorri manualmente todos os fluxos de cadastro, login, upload, moderação, exclusão, push e uso offline. A análise não pode garantir que não exista outro bug.
- O controle diário é por conta autenticada; antes de abrir o site publicamente, ainda vale revisar os limites de gasto da API e monitorar o consumo.

## Repositório GitHub

A recomendação continua sendo um único repositório privado para o site e a pasta `supabase/`, com os scripts SQL de configuração e este relatório. Não encontrei valores de chave OpenAI ou chave secreta de serviço dentro dos arquivos do site; os nomes de variáveis de ambiente aparecem nas Edge Functions. Antes de publicar o repositório, não incluir `.env`, chaves secretas, tokens ou dados pessoais reais.

## Revisão adicional do código — 20/10/2026

Esta revisão foi estática: li os arquivos atuais do projeto, sem executar os fluxos no navegador nem consultar o estado atual do banco e das configurações no painel Supabase. Portanto, os pontos abaixo descrevem o que o código local mostra; não confirmam quais funções e segredos estão publicados no serviço.

### Achados prioritários

1. **Apagar dados não remove as imagens do perfil.** O botão apaga os arquivos do bucket `community-photos`, mas fotos e banners de perfil ficam no bucket separado `community-profile-media`. Apagar também a linha do perfil pode deixar esses arquivos órfãos. Corrigir a exclusão para limpar os dois buckets e confirmar os nomes dos objetos antes de informar sucesso.
2. **Notificações push ainda estão bloqueadas no site local.** `PUSH_VAPID_PUBLIC_KEY` continua com o texto de preenchimento. O botão encerra a ativação nesse ponto. A configuração no painel/cron não foi verificada nesta revisão; o site precisa receber a chave pública correta e o fluxo deve ser conferido de ponta a ponta.
3. **Envio para moderação da comunidade não tem limite de frequência visível na função.** Cada tentativa pode chamar a API de moderação do texto e, com foto, também da imagem. A função pede login, mas não impõe cota por conta ou limite geral no código revisado. Criar limite no servidor antes de divulgar amplamente para reduzir spam e custo inesperado.
4. **Busca de ajuda local é apenas uma pesquisa no Google Maps.** A tela não confirma qual serviço é o mais próximo nem garante telefone atualizado. Ajustar o texto para deixar claro que é uma busca externa; numa etapa futura, usar uma fonte confiável de serviços e validar região/contatos.

### Observações

- O diário e parte do cuidado podem ficar no `localStorage` deste navegador; sem entrar na conta, não sincronizam entre dispositivos. Em aparelho compartilhado, outra pessoa com acesso ao navegador pode ver esses dados.
- O painel de visitas conta identificadores de sessão enviados pelo navegador; pode ser inflado e não representa pessoas únicas. Manter o rótulo de estimativa e não usar como métrica auditada.
- A IA do diário tem limite de 10 respostas por conta/dia no SQL local, mas a disponibilidade depende de saldo e configuração da API. A análise automática de relatos também não substitui revisão humana.
- A tela “Meu progresso” recém-reunida ainda precisa de uma conferência visual em computador e celular, incluindo navegação, botão “Ver tudo”, edição e exclusão de registros.
- O cabeçalho deste relatório e as afirmações anteriores sobre publicação/configuração no Supabase vêm da revisão de 19/10. Não foram revalidados no painel nesta rodada.

### Sequência sugerida para quarta-feira, 21/10

1. Corrigir e conferir a exclusão completa dos dados, incluindo fotos e banners de perfil.
2. Colocar limite de frequência do lado do servidor para moderação e revisar limites de gasto da API.
3. Completar a configuração do push: chave pública no site, segredos no servidor, cron e teste com o navegador fechado.
4. Conferir visualmente a navegação consolidada e testar os fluxos principais: conta, registro, sincronização, edição/exclusão, comunidade, revisão e exportação.
5. Revisar a tela de ajuda local e os avisos de privacidade; depois atualizar este relatório com o que foi realmente verificado.
