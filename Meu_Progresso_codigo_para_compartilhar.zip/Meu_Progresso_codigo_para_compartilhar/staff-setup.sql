-- Funções restritas de equipe. Somente Edge Functions com service role leem ou alteram esta tabela.
create table if not exists public.site_staff (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('analyst', 'support')),
  added_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);
alter table public.site_staff enable row level security;
revoke all on public.site_staff from anon, authenticated;
grant all on public.site_staff to service_role;
