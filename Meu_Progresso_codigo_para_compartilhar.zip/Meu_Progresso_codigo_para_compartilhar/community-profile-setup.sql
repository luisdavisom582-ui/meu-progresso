-- Perfil público opcional, mídia privada e nomes de usuário únicos.
alter table public.community_profiles
  add column if not exists username text,
  add column if not exists bio text not null default '',
  add column if not exists avatar_path text,
  add column if not exists banner_path text,
  add column if not exists is_public boolean not null default false,
  add column if not exists show_in_posts boolean not null default true,
  add column if not exists accent_color text not null default '#527a5b';

alter table public.community_posts add column if not exists profile_username text;

do $$ begin
  if not exists (select 1 from pg_constraint where conname = 'community_profiles_username_format') then
    alter table public.community_profiles add constraint community_profiles_username_format
      check (username is null or username ~ '^[a-z0-9_]{3,20}$');
  end if;
  if not exists (select 1 from pg_constraint where conname = 'community_profiles_bio_length') then
    alter table public.community_profiles add constraint community_profiles_bio_length
      check (char_length(bio) <= 240);
  end if;
  if not exists (select 1 from pg_constraint where conname = 'community_profiles_accent_color_format') then
    alter table public.community_profiles add constraint community_profiles_accent_color_format
      check (accent_color ~ '^#[0-9A-Fa-f]{6}$');
  end if;
end $$;

create unique index if not exists community_profiles_username_unique_idx
  on public.community_profiles (lower(username)) where username is not null;

grant select (profile_username) on public.community_posts to anon, authenticated;

-- Perfil e publicação são escritos por Edge Function para validar campos e moderar imagens.
revoke insert, update, delete on public.community_profiles from anon, authenticated;
grant select on public.community_profiles to authenticated;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('community-profile-media', 'community-profile-media', false, 4194304, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public = false, file_size_limit = 4194304,
  allowed_mime_types = array['image/jpeg','image/png','image/webp'];

drop policy if exists "profile owners read their media" on storage.objects;
create policy "profile owners read their media" on storage.objects for select to authenticated
  using (bucket_id = 'community-profile-media' and (storage.foldername(name))[1] = (select auth.uid()::text));
drop policy if exists "profile owners upload their media" on storage.objects;
create policy "profile owners upload their media" on storage.objects for insert to authenticated
  with check (bucket_id = 'community-profile-media' and (storage.foldername(name))[1] = (select auth.uid()::text));
drop policy if exists "profile owners replace their media" on storage.objects;
create policy "profile owners replace their media" on storage.objects for update to authenticated
  using (bucket_id = 'community-profile-media' and (storage.foldername(name))[1] = (select auth.uid()::text))
  with check (bucket_id = 'community-profile-media' and (storage.foldername(name))[1] = (select auth.uid()::text));
drop policy if exists "profile owners delete their media" on storage.objects;
create policy "profile owners delete their media" on storage.objects for delete to authenticated
  using (bucket_id = 'community-profile-media' and (storage.foldername(name))[1] = (select auth.uid()::text));
