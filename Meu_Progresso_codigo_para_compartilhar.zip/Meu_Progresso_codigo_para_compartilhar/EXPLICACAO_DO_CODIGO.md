# Guia para explicar o site Meu Progresso

Este guia serve para apresentar o projeto e explicar, com palavras simples, o que cada parte faz e como elas trabalham juntas.

## Uma explicação curta

> “O Meu Progresso é um site para registrar metas e acompanhar pequenas conquistas. A interface é feita com HTML, CSS e JavaScript. O Supabase cuida das contas e guarda dados que precisam ser sincronizados. Algumas tarefas, como revisar relatos da comunidade, passam por funções seguras no servidor, escritas em TypeScript.”

## Como as partes se conectam

```text
Pessoa usando o navegador
        │
        ├── index.html: telas, formulários e estilos
        ├── JavaScript: cliques, validações e atualização das telas
        │
        └── Supabase
             ├── Auth: login e sessão
             ├── PostgreSQL: dados organizados em tabelas
             ├── Storage: fotos e arquivos
             └── Edge Functions: tarefas protegidas executadas no servidor
```

O navegador mostra a interface e responde às ações da pessoa. Quando precisa guardar ou consultar dados da conta, conversa com o Supabase. A chave pública do Supabase pode estar no navegador; chaves secretas ficam apenas nos segredos das funções do servidor.

## Arquivos principais

### `index.html` — estrutura, visual e navegação

É o ponto de entrada do site. Nele ficam as seções como Painel, Registros, Meu dia, Comunidade, Perfil e Equipe. O CSS define cores, espaçamento e adaptação para celular. O JavaScript da página cuida, entre outras coisas, das metas pessoais, dos registros, dos gráficos, do diário e do login.

Uma tela pode ser escondida ou exibida sem abrir outro arquivo: a navegação chama `showPage(...)`, que ativa a seção escolhida.

### `community.js` — comunidade e perfil

Cuida do formulário de relatos, do mural, das reações disponíveis atualmente, das denúncias e da personalização do perfil. Também prepara as fotos e o recorte do avatar e do banner.

### `community-review.js` — área da equipe

Busca a fila de relatos e denúncias, mostra as ferramentas da equipe e envia decisões de aprovação ou remoção. Também permite que a conta responsável gerencie administradores, analistas e suporte.

### `supabase/functions/` — funções do servidor

São programas TypeScript executados no Supabase. Fazem operações que não devem depender apenas do navegador, como verificar a sessão e o papel da conta, analisar envios e entregar conteúdo privado para revisão.

### Arquivos `.sql` — banco de dados

Contêm instruções SQL para criar tabelas, campos, índices e regras de acesso. O banco usa PostgreSQL. As regras impedem que uma conta comum consulte dados de outra pessoa ou conceda a si mesma acesso administrativo.

### `sw.js` e `manifest.webmanifest` — instalação e cache

O manifesto descreve o site instalável. O service worker ajuda a manter arquivos essenciais disponíveis e controla a versão do cache, para que mudanças recentes não fiquem presas numa cópia antiga do navegador.

## O que acontece em alguns fluxos

### 1. Criar ou entrar numa conta

1. A pessoa envia e-mail e senha pelo formulário de login.
2. O JavaScript chama o Supabase Auth.
3. O Supabase valida os dados e devolve uma sessão.
4. O site usa essa sessão para associar operações futuras à conta correta.

As senhas não são guardadas no código do site.

### 2. Salvar progresso

1. A pessoa registra uma atividade e escolhe área, data e pontos.
2. O JavaScript atualiza a tela e guarda uma cópia local no navegador.
3. Quando a pessoa está conectada, os registros também são sincronizados com tabelas do Supabase.
4. O painel soma os pontos e desenha o gráfico a partir dos registros.

Áreas e registros pessoais são diferentes de relatos públicos da comunidade: os primeiros acompanham a jornada individual.

### 3. Enviar um relato para a comunidade

1. A pessoa escreve o relato, escolhe se quer anonimato e autoriza o envio.
2. O navegador chama a função `community-submit`.
3. A função verifica a sessão e os campos; se houver foto, também verifica o formato e o tamanho.
4. O texto e a foto passam pela checagem automática configurada.
5. Se aceito pela checagem, o relato é gravado como `pending` — aguardando revisão humana.
6. Administradores e analistas consultam essa fila em **Equipe → Análises**.
7. A decisão humana muda o estado para publicado ou removido.

Um retorno HTTP bem-sucedido sozinho não significa que o relato foi salvo: a checagem automática pode barrar o conteúdo antes da gravação. O formulário mostra uma mensagem para explicar o resultado.

### 4. Controlar o acesso da equipe

O servidor consulta tabelas protegidas para descobrir se a pessoa é responsável, administradora, analista ou suporte. A interface esconde opções que não pertencem àquela função, mas a proteção principal também acontece no servidor — esconder um botão, sozinho, não seria segurança suficiente.

- Administradores e analistas podem abrir o painel e revisar conteúdo.
- Analistas podem revisar relatos e denúncias.
- Suporte recebe orientações de recuperação de conta pelo fluxo oficial de redefinição por e-mail.
- Somente a conta responsável pode conceder ou retirar essas funções.

## O que cada linguagem faz

- **HTML** organiza os elementos da página.
- **CSS** define a aparência e o layout.
- **JavaScript** responde às ações no navegador e atualiza a interface.
- **TypeScript** implementa as funções do servidor com tipos explícitos.
- **SQL** cria e consulta as tabelas do PostgreSQL.

## Como abrir para mostrar o projeto

1. Abra a pasta `outputs` no Visual Studio Code.
2. Inicie `index.html` com a extensão Live Server.
3. O navegador abre o site localmente. Os arquivos devem permanecer juntos na mesma pasta.

## Como explicar o que fizemos

Você pode dizer:

> “Primeiro organizamos as telas e os formulários em HTML e CSS. Depois usamos JavaScript para fazer a navegação e as interações funcionarem. Para login, sincronização e arquivos usamos o Supabase. Nas funções do servidor, em TypeScript, verificamos permissões e cuidamos de ações sensíveis. Por fim, criamos tabelas e regras em SQL para os dados ficarem organizados e protegidos.”

As reações extras e a opção de permitir comentários por publicação são melhorias planejadas; ainda não fazem parte do fluxo atual.
